package main

import (
	"bytes"
	"crypto"
	"crypto/ecdsa"
	"crypto/rand"
	"crypto/rsa"
	"crypto/sha1"
	"crypto/x509"
	"encoding/json"
	"encoding/pem"
	"errors"
	"fmt"
	"io/ioutil"
	"log"
	"net/http"

	"github.com/Northern-Lights/going/file"
)

func main() {
	//data, err := LoadPrivate("echo-api-cert-7.pem")
	//fmt.Println(data)
	//
	//return

	privateKey, err := rsa.GenerateKey(rand.Reader, 1024)
	if err != nil {
		fmt.Printf("rsa.GenerateKey: %v\n", err)
		return
	}

	//f, err := os.Create("data.txt")
	//
	//if err != nil {
	//	log.Fatal(err)
	//}
	//
	//defer f.Close()
	//
	//_, err2 := f.WriteString("old falcon\n")
	//
	//if err2 != nil {
	//	log.Fatal(err2)
	//}
	//
	//fmt.Println("done")
	//
	//
	fmt.Printf("private  ßoutput\n %s\n", (privateKey))

	message := `{"version":"1.0","session":{"new":true,"sessionId":"amzn1.echo-api.session.59072b44-48d0-4d0f-9ecc-d18c662abc4e","application":{"applicationId":"amzn1.ask.skill.c966b8cb-80bc-4482-8ddf-63af59ca07fc"},"user":{"userId":"amzn1.ask.account.AHT5VCB7TV7OFC37NI36O455PN5M65RDNQYF7I2UZFHIVGYL32CYNKUFGJKPRZP4YLIZ2COLBATRRAQI76NRRENEMCT4SZK5YX3XCWADQVIVVPEPN657YJK3MOOXDMDVVLXMHKPIPKFYV6HJOXASGCQOBFJGK4ZR4CIINOSARBCTSPXFPFJ2Q7NDVGAKFGKBKOXVPW73H3CLWFI","permissions":{"consentToken":"eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImtpZCI6IjEifQ.eyJhdWQiOiJodHRwczovL2FwaS5hbWF6b25hbGV4YS5jb20iLCJpc3MiOiJBbGV4YVNraWxsS2l0Iiwic3ViIjoiYW16bjEuYXNrLnNraWxsLmM5NjZiOGNiLTgwYmMtNDQ4Mi04ZGRmLTYzYWY1OWNhMDdmYyIsImV4cCI6MTU2MzIzNDI2MywiaWF0IjoxNTYzMjMwNjYzLCJuYmYiOjE1NjMyMzA2NjMsInByaXZhdGVDbGFpbXMiOnsiaXNEZXByZWNhdGVkIjoidHJ1ZSIsImNvbnNlbnRUb2tlbiI6IkF0emF8SXdFQklDQm5FSmJNXzJUNTR4MnVlTml5eUdLREtBMnRmYTFwMjZlU1FZWUh6Smp2VFJCY3lpMXI0dzJXM2VFVjNJUnFiV29TVjhDbFBqN1VleXFYNk9YbEM0MUxyaXNMOEFGb3JUeS1rejhEQmFKM21SRjNXUC1STFQxQjVWMHZZUlVyTjZqYjZqLU5jRFZKNnpXRk9sSTdXY2tGYi1Jb1RPbDVKMHVXenZjNlEyajYzeGR5bmZ3VUVlTUFqdXBNRUszLVpJQ3lrcHRQLURBc29MNkowOTBPelg2aEFTSlNxQzZxa2VjdGpTLUpET1ZiRVBOWFhYMTNmNmNUX09fSVg1czNIWUI3dFM0NUVzUnFmeW1IN0Q1MWNfRlpFUW1DTERRaDZXb1lqaWR6U2tJYk1TMUNkd3FybVlyeDl1Zmx6LXBKeGVyMl9rSnc4YVNVcHVTSUIzU0QwYXQxQUhBTDBQWWNSa2I2NmFRcGU5X0F3S2Z0aFJtVkxseUg5VlJEeUVnSG42Mm9mU3dNbXNMOGlRN0JwNWR6SWhCMWhnVWxTRTVGNjhOUjNUdm12SlJlbTdlTmpYZlBFM1JON2tudGdtdXl3Wi1UV1loZEJiTVE1YUtTY09QTHpZaDdNZVk2dVA5dkxRVldJMlpQNzlNSDV1YnhmYTV5WVhSQmwtSkxvLTFPMjBMX0xCQlJEcWF5cXBwZ1ZWZFo1WnB0ZV9BLUlHZ0F0VVZBRjdxc2lrSktIVlhRLUZmeHo5dTNtaTJrYWVVRzdITSIsImRldmljZUlkIjoiYW16bjEuYXNrLmRldmljZS5BSENQS0czSlFNNjNJSFBaMjJFUk1MMlUzN0tZNjIyRlVWNlpRREhDWUJIRFRKT08zSDQzMkxOU1JFQjNUQkpWSUNZS0hTR0lZVE1MWDJBWlo2TlVLR0hLRllBQkNIRFNINDZFMzQ0M0VMSEhORk5ZNTYzVDVJS0JHR0pWQk9KUUxXV05MMllaV1g2NTVQVlY3UU5ZMldPMzdWNUEiLCJ1c2VySWQiOiJhbXpuMS5hc2suYWNjb3VudC5BSFQ1VkNCN1RWN09GQzM3TkkzNk80NTVQTjVNNjVSRE5RWUY3STJVWkZISVZHWUwzMkNZTktVRkdKS1BSWlA0WUxJWjJDT0xCQVRSUkFRSTc2TlJSRU5FTUNUNFNaSzVZWDNYQ1dBRFFWSVZWUEVQTjY1N1lKSzNNT09YRE1EVlZMWE1IS1BJUEtGWVY2SEpPWEFTR0NRT0JGSkdLNFpSNENJSU5PU0FSQkNUU1BYRlBGSjJRN05EVkdBS0ZHS0JLT1hWUFc3M0gzQ0xXRkkifX0.akhX0SJ5IRCKAhtxxysDfTU0tn_uBD4c3nXISFMT9dH3xieqVtGLWDhKg4tWGzSUzUWqsa6hqxPJTW9ws8UIU197blJJYfxVTg_beJ5u5gtMU6vPCfByRmpY-IaQo8ETWWW0mN7Zej77_wh42n9K4RNGmhZmaUvdr7h93c6El4DX6m5RYWc76u62SOJQb4O7_dgRvQWXVeTm0GJHO-WhdvTxbUQl4J8PpJX513ox75r4kJ3hpS0xp7MMJ5fNoyYirr0v5Ft0P_IV3KTM85kJYHjVswoMNZ7u0agE0fHHKLnfKPJD8KJlACs0MqvF_2mGnitXeW5WhgUogkOIzrL1mw","scopes":{"alexa::devices:all:geolocation:read":{"status":"GRANTED"}}}}},"context":{"System":{"application":{"applicationId":"amzn1.ask.skill.c966b8cb-80bc-4482-8ddf-63af59ca07fc"},"user":{"userId":"amzn1.ask.account.AHT5VCB7TV7OFC37NI36O455PN5M65RDNQYF7I2UZFHIVGYL32CYNKUFGJKPRZP4YLIZ2COLBATRRAQI76NRRENEMCT4SZK5YX3XCWADQVIVVPEPN657YJK3MOOXDMDVVLXMHKPIPKFYV6HJOXASGCQOBFJGK4ZR4CIINOSARBCTSPXFPFJ2Q7NDVGAKFGKBKOXVPW73H3CLWFI","permissions":{"consentToken":"eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImtpZCI6IjEifQ.eyJhdWQiOiJodHRwczovL2FwaS5hbWF6b25hbGV4YS5jb20iLCJpc3MiOiJBbGV4YVNraWxsS2l0Iiwic3ViIjoiYW16bjEuYXNrLnNraWxsLmM5NjZiOGNiLTgwYmMtNDQ4Mi04ZGRmLTYzYWY1OWNhMDdmYyIsImV4cCI6MTU2MzIzNDI2MywiaWF0IjoxNTYzMjMwNjYzLCJuYmYiOjE1NjMyMzA2NjMsInByaXZhdGVDbGFpbXMiOnsiaXNEZXByZWNhdGVkIjoidHJ1ZSIsImNvbnNlbnRUb2tlbiI6IkF0emF8SXdFQklDQm5FSmJNXzJUNTR4MnVlTml5eUdLREtBMnRmYTFwMjZlU1FZWUh6Smp2VFJCY3lpMXI0dzJXM2VFVjNJUnFiV29TVjhDbFBqN1VleXFYNk9YbEM0MUxyaXNMOEFGb3JUeS1rejhEQmFKM21SRjNXUC1STFQxQjVWMHZZUlVyTjZqYjZqLU5jRFZKNnpXRk9sSTdXY2tGYi1Jb1RPbDVKMHVXenZjNlEyajYzeGR5bmZ3VUVlTUFqdXBNRUszLVpJQ3lrcHRQLURBc29MNkowOTBPelg2aEFTSlNxQzZxa2VjdGpTLUpET1ZiRVBOWFhYMTNmNmNUX09fSVg1czNIWUI3dFM0NUVzUnFmeW1IN0Q1MWNfRlpFUW1DTERRaDZXb1lqaWR6U2tJYk1TMUNkd3FybVlyeDl1Zmx6LXBKeGVyMl9rSnc4YVNVcHVTSUIzU0QwYXQxQUhBTDBQWWNSa2I2NmFRcGU5X0F3S2Z0aFJtVkxseUg5VlJEeUVnSG42Mm9mU3dNbXNMOGlRN0JwNWR6SWhCMWhnVWxTRTVGNjhOUjNUdm12SlJlbTdlTmpYZlBFM1JON2tudGdtdXl3Wi1UV1loZEJiTVE1YUtTY09QTHpZaDdNZVk2dVA5dkxRVldJMlpQNzlNSDV1YnhmYTV5WVhSQmwtSkxvLTFPMjBMX0xCQlJEcWF5cXBwZ1ZWZFo1WnB0ZV9BLUlHZ0F0VVZBRjdxc2lrSktIVlhRLUZmeHo5dTNtaTJrYWVVRzdITSIsImRldmljZUlkIjoiYW16bjEuYXNrLmRldmljZS5BSENQS0czSlFNNjNJSFBaMjJFUk1MMlUzN0tZNjIyRlVWNlpRREhDWUJIRFRKT08zSDQzMkxOU1JFQjNUQkpWSUNZS0hTR0lZVE1MWDJBWlo2TlVLR0hLRllBQkNIRFNINDZFMzQ0M0VMSEhORk5ZNTYzVDVJS0JHR0pWQk9KUUxXV05MMllaV1g2NTVQVlY3UU5ZMldPMzdWNUEiLCJ1c2VySWQiOiJhbXpuMS5hc2suYWNjb3VudC5BSFQ1VkNCN1RWN09GQzM3TkkzNk80NTVQTjVNNjVSRE5RWUY3STJVWkZISVZHWUwzMkNZTktVRkdKS1BSWlA0WUxJWjJDT0xCQVRSUkFRSTc2TlJSRU5FTUNUNFNaSzVZWDNYQ1dBRFFWSVZWUEVQTjY1N1lKSzNNT09YRE1EVlZMWE1IS1BJUEtGWVY2SEpPWEFTR0NRT0JGSkdLNFpSNENJSU5PU0FSQkNUU1BYRlBGSjJRN05EVkdBS0ZHS0JLT1hWUFc3M0gzQ0xXRkkifX0.akhX0SJ5IRCKAhtxxysDfTU0tn_uBD4c3nXISFMT9dH3xieqVtGLWDhKg4tWGzSUzUWqsa6hqxPJTW9ws8UIU197blJJYfxVTg_beJ5u5gtMU6vPCfByRmpY-IaQo8ETWWW0mN7Zej77_wh42n9K4RNGmhZmaUvdr7h93c6El4DX6m5RYWc76u62SOJQb4O7_dgRvQWXVeTm0GJHO-WhdvTxbUQl4J8PpJX513ox75r4kJ3hpS0xp7MMJ5fNoyYirr0v5Ft0P_IV3KTM85kJYHjVswoMNZ7u0agE0fHHKLnfKPJD8KJlACs0MqvF_2mGnitXeW5WhgUogkOIzrL1mw","scopes":{"alexa::devices:all:geolocation:read":{"status":"GRANTED"}}}},"device":{"deviceId":"amzn1.ask.device.AHCPKG3JQM63IHPZ22ERML2U37KY622FUV6ZQDHCYBHDTJOO3H432LNSREB3TBJVICYKHSGIYTMLX2AZZ6NUKGHKFYABCHDSH46E3443ELHHNFNY563T5IKBGGJVBOJQLWWNL2YZWX655PVV7QNY2WO37V5A","supportedInterfaces":{"Geolocation":{}}},"apiEndpoint":"https://api.amazonalexa.com","apiAccessToken":"eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImtpZCI6IjEifQ.eyJhdWQiOiJodHRwczovL2FwaS5hbWF6b25hbGV4YS5jb20iLCJpc3MiOiJBbGV4YVNraWxsS2l0Iiwic3ViIjoiYW16bjEuYXNrLnNraWxsLmM5NjZiOGNiLTgwYmMtNDQ4Mi04ZGRmLTYzYWY1OWNhMDdmYyIsImV4cCI6MTU2MzIzMDk2MywiaWF0IjoxNTYzMjMwNjYzLCJuYmYiOjE1NjMyMzA2NjMsInByaXZhdGVDbGFpbXMiOnsiY29udGV4dCI6IkFBQUFBQUFBQUFCU0RRbFNXNkkyZGc1SkRQK2FuUGI0SkFFQUFBQUFBQUIyc1MxUmo3LzBORkxCTVJ3ZlVQT1BjWEp3RWlBUXdjZ1lzM0duZi9iYzEvVEgyN0YzN0Y0bzBrNlF0aWJCdUdSTWtDZDg5TWdBaWljSUtabTlvazVyMWxLc29WNFNSY3BGSEZ2ZFpnTDFPTWNXcUs0Nk9VQUl1cVdKazJ5dVlUSldWcmFYc2ZYVUNQdHNvdUNSSXZwVHpkZWZ1TzBsVFdzeFVwZTlRTGN2b2lRN1piQnhPMDFvb0dLeUNFT2puRk9lTURCbm5vdHI4c28xZE9rcWpXanJuRnc4M2k2ZERraUJUemdOd0hyY0cyZnBTUk51QVpKTXI1OG9JWXAwaHh4MnBSajkybi85ZkFjT0hMWDJIN2RnQXJyeVA3OHZIRU0yNjl6T3ZMWVMwK0wwNFkxVTFaVGl5OURid0UrRURBNksreGZ0dWROMyt0VTJQUkRTRWxTNzYwYmpiV3VKSzludFA4VzliZTRtSUI4RVdIbm8wdFFlc3g4U0dSbXlSUW5PemtRZCIsImNvbnNlbnRUb2tlbiI6IkF0emF8SXdFQklDQm5FSmJNXzJUNTR4MnVlTml5eUdLREtBMnRmYTFwMjZlU1FZWUh6Smp2VFJCY3lpMXI0dzJXM2VFVjNJUnFiV29TVjhDbFBqN1VleXFYNk9YbEM0MUxyaXNMOEFGb3JUeS1rejhEQmFKM21SRjNXUC1STFQxQjVWMHZZUlVyTjZqYjZqLU5jRFZKNnpXRk9sSTdXY2tGYi1Jb1RPbDVKMHVXenZjNlEyajYzeGR5bmZ3VUVlTUFqdXBNRUszLVpJQ3lrcHRQLURBc29MNkowOTBPelg2aEFTSlNxQzZxa2VjdGpTLUpET1ZiRVBOWFhYMTNmNmNUX09fSVg1czNIWUI3dFM0NUVzUnFmeW1IN0Q1MWNfRlpFUW1DTERRaDZXb1lqaWR6U2tJYk1TMUNkd3FybVlyeDl1Zmx6LXBKeGVyMl9rSnc4YVNVcHVTSUIzU0QwYXQxQUhBTDBQWWNSa2I2NmFRcGU5X0F3S2Z0aFJtVkxseUg5VlJEeUVnSG42Mm9mU3dNbXNMOGlRN0JwNWR6SWhCMWhnVWxTRTVGNjhOUjNUdm12SlJlbTdlTmpYZlBFM1JON2tudGdtdXl3Wi1UV1loZEJiTVE1YUtTY09QTHpZaDdNZVk2dVA5dkxRVldJMlpQNzlNSDV1YnhmYTV5WVhSQmwtSkxvLTFPMjBMX0xCQlJEcWF5cXBwZ1ZWZFo1WnB0ZV9BLUlHZ0F0VVZBRjdxc2lrSktIVlhRLUZmeHo5dTNtaTJrYWVVRzdITSIsImRldmljZUlkIjoiYW16bjEuYXNrLmRldmljZS5BSENQS0czSlFNNjNJSFBaMjJFUk1MMlUzN0tZNjIyRlVWNlpRREhDWUJIRFRKT08zSDQzMkxOU1JFQjNUQkpWSUNZS0hTR0lZVE1MWDJBWlo2TlVLR0hLRllBQkNIRFNINDZFMzQ0M0VMSEhORk5ZNTYzVDVJS0JHR0pWQk9KUUxXV05MMllaV1g2NTVQVlY3UU5ZMldPMzdWNUEiLCJ1c2VySWQiOiJhbXpuMS5hc2suYWNjb3VudC5BSFQ1VkNCN1RWN09GQzM3TkkzNk80NTVQTjVNNjVSRE5RWUY3STJVWkZISVZHWUwzMkNZTktVRkdKS1BSWlA0WUxJWjJDT0xCQVRSUkFRSTc2TlJSRU5FTUNUNFNaSzVZWDNYQ1dBRFFWSVZWUEVQTjY1N1lKSzNNT09YRE1EVlZMWE1IS1BJUEtGWVY2SEpPWEFTR0NRT0JGSkdLNFpSNENJSU5PU0FSQkNUU1BYRlBGSjJRN05EVkdBS0ZHS0JLT1hWUFc3M0gzQ0xXRkkifX0.AL55l104LddLOfbB9avSNhXqr03y6o3dLieCn6fCW4zOwj-WXCA0ihRy8xRT3TT_s5F07kk6mmW0kgsu_nKB68O6fkn7JWjbY9mCwLROehjcYtkeW01SZfhYbNvLtYvpHcnism-vIHu_-s9QNMkZOJ0FXeOSv05gLVE--H9mPJPiX71FBKqQADPtn5F_6j6uS6_q8i7EdC3hpcX8sIGMxL1PVmRWwGs85Y35CQgibNmcEEtHCua0qQYfpeyo9YiVPLRlvC9JGHGpmZPZd8V0pNM6l0FzqfgFJF0gxDPcV7mKkSYTbqOUkjVvIjm_8yvEa1eBOSlFM7qE4eqZI45W2Q"},"Geolocation":{"timestamp":"2019-07-15T22:44:21Z","coordinate":{"latitudeInDegrees":47.61602783203125,"longitudeInDegrees":-122.34012205622135,"accuracyInMeters":10.0},"altitude":{"altitudeInMeters":32.629310607910156,"accuracyInMeters":10.0},"heading":{"directionInDegrees":106.13360595703125},"speed":{"speedInMetersPerSecond":1.0}}},"request":{"type":"LaunchRequest","requestId":"amzn1.echo-api.request.ea2d2b70-7b8e-4b18-9cfa-37c55c7464d5","timestamp":"2019-07-15T22:44:23Z","locale":"en-US","shouldLinkResultBeReturned":false}}`
	messageBytes := bytes.NewBufferString(message)
	hash := sha1.New()
	hash.Write(messageBytes.Bytes())
	digest := hash.Sum(nil)

	//fmt.Printf("messageBytes: %v\n", messageBytes)
	//fmt.Printf("hash: %V\n", hash)
	//fmt.Printf("digest: %v\n", digest)

	signature, err := rsa.SignPKCS1v15(rand.Reader, privateKey, crypto.SHA1, digest)

	empJSON, err := json.MarshalIndent(signature, "", "  ")
	if err != nil {
		log.Fatalf(err.Error())
	}
	fmt.Printf("MarshalIndent funnction output\n %s\n", string(empJSON))

	if err != nil {
		fmt.Printf("rsa.SignPKCS1v15 error: %v\n", err)
		return
	}

	err = rsa.VerifyPKCS1v15(&privateKey.PublicKey, crypto.SHA1, digest, signature)
	if err != nil {
		fmt.Printf("rsa.VerifyPKCS1v15 error: %V\n", err)
	}

	fmt.Println("Signature good!")
}
func main_() {
	message := `{"version":"1.0","session":{"new":true,"sessionId":"amzn1.echo-api.session.59072b44-48d0-4d0f-9ecc-d18c662abc4e","application":{"applicationId":"amzn1.ask.skill.c966b8cb-80bc-4482-8ddf-63af59ca07fc"},"user":{"userId":"amzn1.ask.account.AHT5VCB7TV7OFC37NI36O455PN5M65RDNQYF7I2UZFHIVGYL32CYNKUFGJKPRZP4YLIZ2COLBATRRAQI76NRRENEMCT4SZK5YX3XCWADQVIVVPEPN657YJK3MOOXDMDVVLXMHKPIPKFYV6HJOXASGCQOBFJGK4ZR4CIINOSARBCTSPXFPFJ2Q7NDVGAKFGKBKOXVPW73H3CLWFI","permissions":{"consentToken":"eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImtpZCI6IjEifQ.eyJhdWQiOiJodHRwczovL2FwaS5hbWF6b25hbGV4YS5jb20iLCJpc3MiOiJBbGV4YVNraWxsS2l0Iiwic3ViIjoiYW16bjEuYXNrLnNraWxsLmM5NjZiOGNiLTgwYmMtNDQ4Mi04ZGRmLTYzYWY1OWNhMDdmYyIsImV4cCI6MTU2MzIzNDI2MywiaWF0IjoxNTYzMjMwNjYzLCJuYmYiOjE1NjMyMzA2NjMsInByaXZhdGVDbGFpbXMiOnsiaXNEZXByZWNhdGVkIjoidHJ1ZSIsImNvbnNlbnRUb2tlbiI6IkF0emF8SXdFQklDQm5FSmJNXzJUNTR4MnVlTml5eUdLREtBMnRmYTFwMjZlU1FZWUh6Smp2VFJCY3lpMXI0dzJXM2VFVjNJUnFiV29TVjhDbFBqN1VleXFYNk9YbEM0MUxyaXNMOEFGb3JUeS1rejhEQmFKM21SRjNXUC1STFQxQjVWMHZZUlVyTjZqYjZqLU5jRFZKNnpXRk9sSTdXY2tGYi1Jb1RPbDVKMHVXenZjNlEyajYzeGR5bmZ3VUVlTUFqdXBNRUszLVpJQ3lrcHRQLURBc29MNkowOTBPelg2aEFTSlNxQzZxa2VjdGpTLUpET1ZiRVBOWFhYMTNmNmNUX09fSVg1czNIWUI3dFM0NUVzUnFmeW1IN0Q1MWNfRlpFUW1DTERRaDZXb1lqaWR6U2tJYk1TMUNkd3FybVlyeDl1Zmx6LXBKeGVyMl9rSnc4YVNVcHVTSUIzU0QwYXQxQUhBTDBQWWNSa2I2NmFRcGU5X0F3S2Z0aFJtVkxseUg5VlJEeUVnSG42Mm9mU3dNbXNMOGlRN0JwNWR6SWhCMWhnVWxTRTVGNjhOUjNUdm12SlJlbTdlTmpYZlBFM1JON2tudGdtdXl3Wi1UV1loZEJiTVE1YUtTY09QTHpZaDdNZVk2dVA5dkxRVldJMlpQNzlNSDV1YnhmYTV5WVhSQmwtSkxvLTFPMjBMX0xCQlJEcWF5cXBwZ1ZWZFo1WnB0ZV9BLUlHZ0F0VVZBRjdxc2lrSktIVlhRLUZmeHo5dTNtaTJrYWVVRzdITSIsImRldmljZUlkIjoiYW16bjEuYXNrLmRldmljZS5BSENQS0czSlFNNjNJSFBaMjJFUk1MMlUzN0tZNjIyRlVWNlpRREhDWUJIRFRKT08zSDQzMkxOU1JFQjNUQkpWSUNZS0hTR0lZVE1MWDJBWlo2TlVLR0hLRllBQkNIRFNINDZFMzQ0M0VMSEhORk5ZNTYzVDVJS0JHR0pWQk9KUUxXV05MMllaV1g2NTVQVlY3UU5ZMldPMzdWNUEiLCJ1c2VySWQiOiJhbXpuMS5hc2suYWNjb3VudC5BSFQ1VkNCN1RWN09GQzM3TkkzNk80NTVQTjVNNjVSRE5RWUY3STJVWkZISVZHWUwzMkNZTktVRkdKS1BSWlA0WUxJWjJDT0xCQVRSUkFRSTc2TlJSRU5FTUNUNFNaSzVZWDNYQ1dBRFFWSVZWUEVQTjY1N1lKSzNNT09YRE1EVlZMWE1IS1BJUEtGWVY2SEpPWEFTR0NRT0JGSkdLNFpSNENJSU5PU0FSQkNUU1BYRlBGSjJRN05EVkdBS0ZHS0JLT1hWUFc3M0gzQ0xXRkkifX0.akhX0SJ5IRCKAhtxxysDfTU0tn_uBD4c3nXISFMT9dH3xieqVtGLWDhKg4tWGzSUzUWqsa6hqxPJTW9ws8UIU197blJJYfxVTg_beJ5u5gtMU6vPCfByRmpY-IaQo8ETWWW0mN7Zej77_wh42n9K4RNGmhZmaUvdr7h93c6El4DX6m5RYWc76u62SOJQb4O7_dgRvQWXVeTm0GJHO-WhdvTxbUQl4J8PpJX513ox75r4kJ3hpS0xp7MMJ5fNoyYirr0v5Ft0P_IV3KTM85kJYHjVswoMNZ7u0agE0fHHKLnfKPJD8KJlACs0MqvF_2mGnitXeW5WhgUogkOIzrL1mw","scopes":{"alexa::devices:all:geolocation:read":{"status":"GRANTED"}}}}},"context":{"System":{"application":{"applicationId":"amzn1.ask.skill.c966b8cb-80bc-4482-8ddf-63af59ca07fc"},"user":{"userId":"amzn1.ask.account.AHT5VCB7TV7OFC37NI36O455PN5M65RDNQYF7I2UZFHIVGYL32CYNKUFGJKPRZP4YLIZ2COLBATRRAQI76NRRENEMCT4SZK5YX3XCWADQVIVVPEPN657YJK3MOOXDMDVVLXMHKPIPKFYV6HJOXASGCQOBFJGK4ZR4CIINOSARBCTSPXFPFJ2Q7NDVGAKFGKBKOXVPW73H3CLWFI","permissions":{"consentToken":"eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImtpZCI6IjEifQ.eyJhdWQiOiJodHRwczovL2FwaS5hbWF6b25hbGV4YS5jb20iLCJpc3MiOiJBbGV4YVNraWxsS2l0Iiwic3ViIjoiYW16bjEuYXNrLnNraWxsLmM5NjZiOGNiLTgwYmMtNDQ4Mi04ZGRmLTYzYWY1OWNhMDdmYyIsImV4cCI6MTU2MzIzNDI2MywiaWF0IjoxNTYzMjMwNjYzLCJuYmYiOjE1NjMyMzA2NjMsInByaXZhdGVDbGFpbXMiOnsiaXNEZXByZWNhdGVkIjoidHJ1ZSIsImNvbnNlbnRUb2tlbiI6IkF0emF8SXdFQklDQm5FSmJNXzJUNTR4MnVlTml5eUdLREtBMnRmYTFwMjZlU1FZWUh6Smp2VFJCY3lpMXI0dzJXM2VFVjNJUnFiV29TVjhDbFBqN1VleXFYNk9YbEM0MUxyaXNMOEFGb3JUeS1rejhEQmFKM21SRjNXUC1STFQxQjVWMHZZUlVyTjZqYjZqLU5jRFZKNnpXRk9sSTdXY2tGYi1Jb1RPbDVKMHVXenZjNlEyajYzeGR5bmZ3VUVlTUFqdXBNRUszLVpJQ3lrcHRQLURBc29MNkowOTBPelg2aEFTSlNxQzZxa2VjdGpTLUpET1ZiRVBOWFhYMTNmNmNUX09fSVg1czNIWUI3dFM0NUVzUnFmeW1IN0Q1MWNfRlpFUW1DTERRaDZXb1lqaWR6U2tJYk1TMUNkd3FybVlyeDl1Zmx6LXBKeGVyMl9rSnc4YVNVcHVTSUIzU0QwYXQxQUhBTDBQWWNSa2I2NmFRcGU5X0F3S2Z0aFJtVkxseUg5VlJEeUVnSG42Mm9mU3dNbXNMOGlRN0JwNWR6SWhCMWhnVWxTRTVGNjhOUjNUdm12SlJlbTdlTmpYZlBFM1JON2tudGdtdXl3Wi1UV1loZEJiTVE1YUtTY09QTHpZaDdNZVk2dVA5dkxRVldJMlpQNzlNSDV1YnhmYTV5WVhSQmwtSkxvLTFPMjBMX0xCQlJEcWF5cXBwZ1ZWZFo1WnB0ZV9BLUlHZ0F0VVZBRjdxc2lrSktIVlhRLUZmeHo5dTNtaTJrYWVVRzdITSIsImRldmljZUlkIjoiYW16bjEuYXNrLmRldmljZS5BSENQS0czSlFNNjNJSFBaMjJFUk1MMlUzN0tZNjIyRlVWNlpRREhDWUJIRFRKT08zSDQzMkxOU1JFQjNUQkpWSUNZS0hTR0lZVE1MWDJBWlo2TlVLR0hLRllBQkNIRFNINDZFMzQ0M0VMSEhORk5ZNTYzVDVJS0JHR0pWQk9KUUxXV05MMllaV1g2NTVQVlY3UU5ZMldPMzdWNUEiLCJ1c2VySWQiOiJhbXpuMS5hc2suYWNjb3VudC5BSFQ1VkNCN1RWN09GQzM3TkkzNk80NTVQTjVNNjVSRE5RWUY3STJVWkZISVZHWUwzMkNZTktVRkdKS1BSWlA0WUxJWjJDT0xCQVRSUkFRSTc2TlJSRU5FTUNUNFNaSzVZWDNYQ1dBRFFWSVZWUEVQTjY1N1lKSzNNT09YRE1EVlZMWE1IS1BJUEtGWVY2SEpPWEFTR0NRT0JGSkdLNFpSNENJSU5PU0FSQkNUU1BYRlBGSjJRN05EVkdBS0ZHS0JLT1hWUFc3M0gzQ0xXRkkifX0.akhX0SJ5IRCKAhtxxysDfTU0tn_uBD4c3nXISFMT9dH3xieqVtGLWDhKg4tWGzSUzUWqsa6hqxPJTW9ws8UIU197blJJYfxVTg_beJ5u5gtMU6vPCfByRmpY-IaQo8ETWWW0mN7Zej77_wh42n9K4RNGmhZmaUvdr7h93c6El4DX6m5RYWc76u62SOJQb4O7_dgRvQWXVeTm0GJHO-WhdvTxbUQl4J8PpJX513ox75r4kJ3hpS0xp7MMJ5fNoyYirr0v5Ft0P_IV3KTM85kJYHjVswoMNZ7u0agE0fHHKLnfKPJD8KJlACs0MqvF_2mGnitXeW5WhgUogkOIzrL1mw","scopes":{"alexa::devices:all:geolocation:read":{"status":"GRANTED"}}}},"device":{"deviceId":"amzn1.ask.device.AHCPKG3JQM63IHPZ22ERML2U37KY622FUV6ZQDHCYBHDTJOO3H432LNSREB3TBJVICYKHSGIYTMLX2AZZ6NUKGHKFYABCHDSH46E3443ELHHNFNY563T5IKBGGJVBOJQLWWNL2YZWX655PVV7QNY2WO37V5A","supportedInterfaces":{"Geolocation":{}}},"apiEndpoint":"https://api.amazonalexa.com","apiAccessToken":"eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImtpZCI6IjEifQ.eyJhdWQiOiJodHRwczovL2FwaS5hbWF6b25hbGV4YS5jb20iLCJpc3MiOiJBbGV4YVNraWxsS2l0Iiwic3ViIjoiYW16bjEuYXNrLnNraWxsLmM5NjZiOGNiLTgwYmMtNDQ4Mi04ZGRmLTYzYWY1OWNhMDdmYyIsImV4cCI6MTU2MzIzMDk2MywiaWF0IjoxNTYzMjMwNjYzLCJuYmYiOjE1NjMyMzA2NjMsInByaXZhdGVDbGFpbXMiOnsiY29udGV4dCI6IkFBQUFBQUFBQUFCU0RRbFNXNkkyZGc1SkRQK2FuUGI0SkFFQUFBQUFBQUIyc1MxUmo3LzBORkxCTVJ3ZlVQT1BjWEp3RWlBUXdjZ1lzM0duZi9iYzEvVEgyN0YzN0Y0bzBrNlF0aWJCdUdSTWtDZDg5TWdBaWljSUtabTlvazVyMWxLc29WNFNSY3BGSEZ2ZFpnTDFPTWNXcUs0Nk9VQUl1cVdKazJ5dVlUSldWcmFYc2ZYVUNQdHNvdUNSSXZwVHpkZWZ1TzBsVFdzeFVwZTlRTGN2b2lRN1piQnhPMDFvb0dLeUNFT2puRk9lTURCbm5vdHI4c28xZE9rcWpXanJuRnc4M2k2ZERraUJUemdOd0hyY0cyZnBTUk51QVpKTXI1OG9JWXAwaHh4MnBSajkybi85ZkFjT0hMWDJIN2RnQXJyeVA3OHZIRU0yNjl6T3ZMWVMwK0wwNFkxVTFaVGl5OURid0UrRURBNksreGZ0dWROMyt0VTJQUkRTRWxTNzYwYmpiV3VKSzludFA4VzliZTRtSUI4RVdIbm8wdFFlc3g4U0dSbXlSUW5PemtRZCIsImNvbnNlbnRUb2tlbiI6IkF0emF8SXdFQklDQm5FSmJNXzJUNTR4MnVlTml5eUdLREtBMnRmYTFwMjZlU1FZWUh6Smp2VFJCY3lpMXI0dzJXM2VFVjNJUnFiV29TVjhDbFBqN1VleXFYNk9YbEM0MUxyaXNMOEFGb3JUeS1rejhEQmFKM21SRjNXUC1STFQxQjVWMHZZUlVyTjZqYjZqLU5jRFZKNnpXRk9sSTdXY2tGYi1Jb1RPbDVKMHVXenZjNlEyajYzeGR5bmZ3VUVlTUFqdXBNRUszLVpJQ3lrcHRQLURBc29MNkowOTBPelg2aEFTSlNxQzZxa2VjdGpTLUpET1ZiRVBOWFhYMTNmNmNUX09fSVg1czNIWUI3dFM0NUVzUnFmeW1IN0Q1MWNfRlpFUW1DTERRaDZXb1lqaWR6U2tJYk1TMUNkd3FybVlyeDl1Zmx6LXBKeGVyMl9rSnc4YVNVcHVTSUIzU0QwYXQxQUhBTDBQWWNSa2I2NmFRcGU5X0F3S2Z0aFJtVkxseUg5VlJEeUVnSG42Mm9mU3dNbXNMOGlRN0JwNWR6SWhCMWhnVWxTRTVGNjhOUjNUdm12SlJlbTdlTmpYZlBFM1JON2tudGdtdXl3Wi1UV1loZEJiTVE1YUtTY09QTHpZaDdNZVk2dVA5dkxRVldJMlpQNzlNSDV1YnhmYTV5WVhSQmwtSkxvLTFPMjBMX0xCQlJEcWF5cXBwZ1ZWZFo1WnB0ZV9BLUlHZ0F0VVZBRjdxc2lrSktIVlhRLUZmeHo5dTNtaTJrYWVVRzdITSIsImRldmljZUlkIjoiYW16bjEuYXNrLmRldmljZS5BSENQS0czSlFNNjNJSFBaMjJFUk1MMlUzN0tZNjIyRlVWNlpRREhDWUJIRFRKT08zSDQzMkxOU1JFQjNUQkpWSUNZS0hTR0lZVE1MWDJBWlo2TlVLR0hLRllBQkNIRFNINDZFMzQ0M0VMSEhORk5ZNTYzVDVJS0JHR0pWQk9KUUxXV05MMllaV1g2NTVQVlY3UU5ZMldPMzdWNUEiLCJ1c2VySWQiOiJhbXpuMS5hc2suYWNjb3VudC5BSFQ1VkNCN1RWN09GQzM3TkkzNk80NTVQTjVNNjVSRE5RWUY3STJVWkZISVZHWUwzMkNZTktVRkdKS1BSWlA0WUxJWjJDT0xCQVRSUkFRSTc2TlJSRU5FTUNUNFNaSzVZWDNYQ1dBRFFWSVZWUEVQTjY1N1lKSzNNT09YRE1EVlZMWE1IS1BJUEtGWVY2SEpPWEFTR0NRT0JGSkdLNFpSNENJSU5PU0FSQkNUU1BYRlBGSjJRN05EVkdBS0ZHS0JLT1hWUFc3M0gzQ0xXRkkifX0.AL55l104LddLOfbB9avSNhXqr03y6o3dLieCn6fCW4zOwj-WXCA0ihRy8xRT3TT_s5F07kk6mmW0kgsu_nKB68O6fkn7JWjbY9mCwLROehjcYtkeW01SZfhYbNvLtYvpHcnism-vIHu_-s9QNMkZOJ0FXeOSv05gLVE--H9mPJPiX71FBKqQADPtn5F_6j6uS6_q8i7EdC3hpcX8sIGMxL1PVmRWwGs85Y35CQgibNmcEEtHCua0qQYfpeyo9YiVPLRlvC9JGHGpmZPZd8V0pNM6l0FzqfgFJF0gxDPcV7mKkSYTbqOUkjVvIjm_8yvEa1eBOSlFM7qE4eqZI45W2Q"},"Geolocation":{"timestamp":"2019-07-15T22:44:21Z","coordinate":{"latitudeInDegrees":47.61602783203125,"longitudeInDegrees":-122.34012205622135,"accuracyInMeters":10.0},"altitude":{"altitudeInMeters":32.629310607910156,"accuracyInMeters":10.0},"heading":{"directionInDegrees":106.13360595703125},"speed":{"speedInMetersPerSecond":1.0}}},"request":{"type":"LaunchRequest","requestId":"amzn1.echo-api.request.ea2d2b70-7b8e-4b18-9cfa-37c55c7464d5","timestamp":"2019-07-15T22:44:23Z","locale":"en-US","shouldLinkResultBeReturned":false}}`
	messageBytes := bytes.NewBufferString(message)
	hash := sha1.New()
	hash.Write(messageBytes.Bytes())
	digest := hash.Sum(nil)
	fmt.Println("digest")
	fmt.Println(string(digest))

}

var (
	cachedCert *x509.Certificate
)

func getX509Certificate(certURL string) (*x509.Certificate, error) {
	if cachedCert != nil {
		return cachedCert, nil
	}

	// Fetch certificate data
	certContents, err := downloadCert(certURL)

	if err != nil {
		return nil, err
	}

	for block, rest := pem.Decode(certContents); block != nil; block, rest = pem.Decode(rest) {
		switch block.Type {
		case "CERTIFICATE":
			_, err := x509.ParseCertificate(block.Bytes)
			if err != nil {
				panic(err)
			}
			fmt.Println("CERTIFICATE")
			// Handle certificate
			//fmt.Printf("%T %#v\n", cert, cert)

		case "PRIVATE KEY":
			_, err := x509.ParsePKCS1PrivateKey(block.Bytes)
			if err != nil {
				panic(err)
			}
			fmt.Println("PRIVATE KEY")
			// Handle private key
			//fmt.Printf("%T %#v\n", key, key)

		default:
			panic("unknown block type")
		}
	}

	// Decode certificate data
	block, _ := pem.Decode(certContents)
	if block == nil {
		return nil, fmt.Errorf("Failed to parse Amazon certificate, %q", certURL)
	}

	//fmt.Printf("MarshalIndent funnction output\n %s\n", (pa))
	//empJSON, err := json.MarshalIndent(pa, "", "  ")
	//if err != nil {
	//	log.Fatalf(err.Error())
	//}
	//fmt.Printf("MarshalIndent funnction output\n %s\n", string(empJSON))

	cert, err := x509.ParseCertificate(block.Bytes)
	if err != nil {
		return nil, err
	}

	// Check the certificate alternate names
	foundName := false
	for _, altName := range cert.Subject.Names {
		if altName.Value == "echo-api.amazon.com" {
			foundName = true
		}
	}

	if !foundName {
		return nil, fmt.Errorf("Invalid Amazon certificate (echo-api SN not found), %q", certURL)
	}

	cachedCert = cert

	return cert, nil
}
func downloadCert(certURL string) ([]byte, error) {
	cert, err := http.Get(certURL)

	if err != nil {
		return nil, errors.New("Could not download Amazon cert file.")
	}
	defer cert.Body.Close()
	certContents, err := ioutil.ReadAll(cert.Body)

	// empJSON2, err := json.MarshalIndent(certContents, "", "  ")
	// if err != nil {
	// 	log.Fatalf(err.Error())
	// }
	// fmt.Printf("certContents output\n %s\n", string(empJSON2))

	if err != nil {
		return nil, errors.New("Could not read Amazon cert file.")
	}

	return certContents, nil
}
func parsePrivateKey(der []byte) (crypto.PrivateKey, error) {
	if key, err := x509.ParsePKCS1PrivateKey(der); err == nil {
		return key, nil
	}
	if key, err := x509.ParsePKCS8PrivateKey(der); err == nil {
		switch key := key.(type) {
		case *rsa.PrivateKey, *ecdsa.PrivateKey:
			return key, nil
		default:
			return nil, fmt.Errorf("Found unknown private key type in PKCS#8 wrapping")
		}
	}
	if key, err := x509.ParseECPrivateKey(der); err == nil {
		return key, nil
	}
	return nil, fmt.Errorf("Failed to parse private key")
}

func LoadPrivate(filepath string) (*rsa.PrivateKey, error) {
	// Read the bytes of the PEM file, e.g. id_rsa
	pemData, e := file.Read(filepath)
	if e != nil {
		return nil, e
	}

	// Use the PEM decoder and parse the private key
	pemBlock, _ := pem.Decode(pemData)
	priv, e := x509.ParsePKCS1PrivateKey(pemBlock.Bytes)
	fmt.Println(pemBlock.Bytes)
	// Public key can be obtained through priv.PublicKey
	return priv, e
}
